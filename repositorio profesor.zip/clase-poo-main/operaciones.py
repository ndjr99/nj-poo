def suma(a, b):
    return a + b 


def resta(a, b):
    return a - b