# clase-poo

Este es mi primer repositorio 